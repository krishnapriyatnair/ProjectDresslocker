import { Component, OnInit } from '@angular/core';
import { KurthaModel } from '../kurthas/kurtha.model';
import { ProductsService } from '../products.service';
import { Router} from '@angular/router';
import{FormsModule} from '@angular/forms';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor(private productService:ProductsService,private router:Router) { }
  productItem=new KurthaModel(null,null,null,null,null,null,null,null,null);
  sub;
  id;
  handler:any = null;
  ngOnInit(): void {
    
    this.productService.payments().subscribe((data)=>{
      console.log(data);
      this.productItem=JSON.parse(JSON.stringify(data));
    })

    this.loadStripe();
  }

  ngOnDestroy()
 {
 this.sub.unsubscribe();
 }
   
  
  pay() {    
  
    var handler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_aeUUjYYcx4XNfKVW60pmHTtI',
      locale: 'auto',
      token: function (token: any) {
        // You can access the token ID with `token.id`.
        // Get the token ID to your server-side code for use.
        console.log(token)
        alert('Token Created!!');
      }
    });
 
    handler.open({
      name: 'Shopping card',
    
    });
 
  }
 
  loadStripe() {
     
    if(!window.document.getElementById('stripe-script')) {
      var s = window.document.createElement("script");
      s.id = "stripe-script";
      s.type = "text/javascript";
      s.src = "https://checkout.stripe.com/checkout.js";
      s.onload = () => {
        this.handler = (<any>window).StripeCheckout.configure({
          key: 'pk_test_aeUUjYYcx4XNfKVW60pmHTtI',
          locale: 'auto',
          token: function (token: any) {
            // You can access the token ID with `token.id`.
            // Get the token ID to your server-side code for use.
            console.log(token)
            alert('Payment Success!!');
          }
        });
      }
       
      window.document.body.appendChild(s);
    }
  }
}