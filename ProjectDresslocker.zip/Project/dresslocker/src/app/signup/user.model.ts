export class UserModel{
    constructor(
        public userName:string,
        public usermobile:number,
        public userPassword:string,
        public userEmail:string,
        public userAddress:string,
        public zipcode:number,
        public usertype:string
      
    ){}
}