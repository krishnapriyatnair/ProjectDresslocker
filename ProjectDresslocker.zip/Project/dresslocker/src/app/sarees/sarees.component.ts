import { Component, OnInit } from '@angular/core';
import{KurthaModel}from '../kurthas/kurtha.model';
import{ProductsService} from '../products.service';
@Component({
  selector: 'app-sarees',
  templateUrl: './sarees.component.html',
  styleUrls: ['./sarees.component.css']
})
export class SareesComponent implements OnInit {
  title:String="Kurthas";
  kurthas:KurthaModel[];
  imageWidth: number=100;
imageMargin:number=2;

constructor(private productsService: ProductsService) { }

  ngOnInit(): void {


    this.productsService.getSarees().subscribe((data)=>{
      console.log(data);
      this.kurthas=JSON.parse(JSON.stringify(data));
    })
  }

}
