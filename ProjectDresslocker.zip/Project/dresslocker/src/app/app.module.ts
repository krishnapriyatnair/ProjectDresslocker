import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{HttpClientModule,HTTP_INTERCEPTORS}from '@angular/common/http';
import{ FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { KurthasComponent } from './kurthas/kurthas.component';
import { from } from 'rxjs';
import { SellproductComponent } from './sellproduct/sellproduct.component';
import { AdmineditComponent } from './adminedit/adminedit.component';
import { UpdateprodComponent } from './updateprod/updateprod.component';
import { SareesComponent } from './sarees/sarees.component';
import { JeansComponent } from './jeans/jeans.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import{UserService} from './user.service';
import{ProductsService}from './products.service';
import{UserGuard}from './user.guard';
import{TolenInterceptorService}from './tolen-interceptor.service';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { FooterComponent } from './footer/footer.component';
import { PaymentComponent } from './payment/payment.component';
import { GownsComponent } from './gowns/gowns.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ProductlistComponent,
    KurthasComponent,
    SellproductComponent,
    AdmineditComponent,
    UpdateprodComponent,
    SareesComponent,
    JeansComponent,
    SignupComponent,
    LoginComponent,
    AdminheaderComponent,
    FooterComponent,
    PaymentComponent,
    GownsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [UserService,UserGuard,ProductsService,
  {
    provide:HTTP_INTERCEPTORS,
    useClass:TolenInterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
