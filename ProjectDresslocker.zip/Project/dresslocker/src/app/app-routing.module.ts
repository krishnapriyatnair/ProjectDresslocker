import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{ProductlistComponent}from './productlist/productlist.component';
import{KurthasComponent}from './kurthas/kurthas.component'
import{SellproductComponent}from './sellproduct/sellproduct.component'
import{UpdateprodComponent} from './updateprod/updateprod.component';
import{AdmineditComponent} from './adminedit/adminedit.component';
import { from } from 'rxjs';
import{SareesComponent}from './sarees/sarees.component';
import{JeansComponent} from './jeans/jeans.component'
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import {UserGuard} from './user.guard';
import{PaymentComponent}from './payment/payment.component';
import{GownsComponent} from './gowns/gowns.component';


const routes: Routes = [{path:'',component:ProductlistComponent},
{path:'kurthas',component:KurthasComponent},
{path:'sarees',component:SareesComponent},
{path:'jeans',component:JeansComponent},
{path:'gowns',component:GownsComponent},
{path:'add',component:SellproductComponent,canActivate:[UserGuard]},
{path:'edit',component:AdmineditComponent,canActivate:[UserGuard]},
{path:'update/:id',component:UpdateprodComponent,canActivate:[UserGuard]},
{path:'signup',component:SignupComponent},
{path:'login',component:LoginComponent},
{path:'payment',component:PaymentComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
