import { Component, OnInit } from '@angular/core';
import{KurthaModel}from '../kurthas/kurtha.model';
import { ProductsService } from '../products.service';
import { Router,ActivatedRoute} from '@angular/router';
import{FormsModule} from '@angular/forms';
import { from,Subscription } from 'rxjs';
@Component({
  selector: 'app-updateprod',
  templateUrl: './updateprod.component.html',
  styleUrls: ['./updateprod.component.css']
})
export class UpdateprodComponent implements OnInit {
  title:String=" UpdateProduct List";
  products:KurthaModel[];
  constructor(private productService:ProductsService,private router:Router,private activatedRoute:ActivatedRoute ) { }
  productItem:KurthaModel=new KurthaModel(null,null,null,null,null,null,null,null,null);
  sub;
id;
  ngOnInit(): void {
    this.sub =  this.activatedRoute.paramMap.subscribe((params)=>
    {
      this.id = params.get('id'); 
this.productService.getProduct(this.id).subscribe((data)=>
{
this.productItem=JSON.parse(JSON.stringify(data));
console.log(this.productItem);
});

console.log(this.productItem);
    });
  }

  ngOnDestroy()
 {
 this.sub.unsubscribe();
 }
    updateProduct():void
   {
     
    if(document.getElementById('Kurthas')['checked'])
    {
    this.productItem.type='Kurthas';
    }
    else if(document.getElementById('Sarees')['checked'])
    {
    this.productItem.type='Sarees';
    }
    else if(document.getElementById('Jeans')['checked'])
    {
    this.productItem.type='Jeans';
    }
    else if(document.getElementById('Gowns')['checked'])
    {
    this.productItem.type='Gowns';
    }
    else{
      console.log("invalid");
    }
     this.productService.updatePro(this.productItem);
     alert("updated the product");
     this.router.navigate(['/edit']);
   }

}

