import { Component, OnInit } from '@angular/core';
import{KurthaModel}from '../kurthas/kurtha.model';
import{ProductsService} from '../products.service';
@Component({
  selector: 'app-jeans',
  templateUrl: './jeans.component.html',
  styleUrls: ['./jeans.component.css']
})
export class JeansComponent implements OnInit {
  title:String="Kurthas";
  kurthas:KurthaModel[];
  imageWidth: number=100;
imageMargin:number=2;

constructor(private productsService: ProductsService) { }

  ngOnInit(): void {


    this.productsService.getJeans().subscribe((data)=>{
      console.log(data);
      this.kurthas=JSON.parse(JSON.stringify(data));
    })
  }

}
