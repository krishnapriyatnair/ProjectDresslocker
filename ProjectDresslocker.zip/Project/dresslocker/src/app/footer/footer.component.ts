import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  aboutUs()
  {
  alert("About us:\n  Here,we endeavor to be more than an online retailer and a destination, an experience for you to come and pamper yourself with all your fashion needs. You can donate your old clothes ,which make a mess at your wardrobe. We desire to inspire, update and inform you of current fashion trends.");
  }

  contactUs()
{
alert("Contact us on :\n Dresslocker\nPhone: +91-3222-282435\nFor any issue or feedback, please write to dresslocker-support@gmail.com");
}
TC()
{
alert("You acknowledge and undertake that you are accessing the services on the website and transacting at your own risk and are using your best and prudent judgment before entering into any transactions through the website. We shall neither be liable nor responsible for any actions or inactions of sellers nor any breach of conditions, representations or warranties by the sellers or manufacturers of the products and hereby expressly disclaim and any all responsibility and liability in that regard. We shall not mediate or resolve any dispute or disagreement between you and the sellers or manufacturers of the products. ");
}
}
