import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';
import { KurthaModel } from '../kurthas/kurtha.model';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-sellproduct',
  templateUrl: './sellproduct.component.html',
  styleUrls: ['./sellproduct.component.css']
})
export class SellproductComponent implements OnInit {
  title:String='Donate your old clothes & win exciting cashback coupons';
  constructor(private productService:ProductsService, private router:Router) { }
  productItem=new KurthaModel(null,null,null,null,null,null,null,null,null);
  ngOnInit(): void {
  }

  AddProduct(){

console.log("Products for sale ");
if(document.getElementById('Kurthas')['checked'])
{
this.productItem.type='Kurthas';
}
else if(document.getElementById('Sarees')['checked'])
{
this.productItem.type='Sarees';
}
else if(document.getElementById('Jeans')['checked'])
{
this.productItem.type='Jeans';
}
else if(document.getElementById('Gowns')['checked'])
{
this.productItem.type='Gowns';
}
else{
  console.log("invalid");
}

    this.productService.sellproduct(this.productItem)
    .subscribe(
     
      err =>{
        if (err instanceof HttpErrorResponse){
          if(err.status===401){
            this.router.navigate(['/login'])
          }
        }
      }

    )
    alert("Thanks for your donating to us.You will recive cash back coupon once the product reaches us!! ");

//     if(document.getElementById('Kurthas')['checked'])
// {
//   this.router.navigate(['/kurthas']);
// }
// else if(document.getElementById('Sarees')['checked'])
// {
//   this.router.navigate(['/sarees']);
// }
// else if(document.getElementById('Jeans')['checked'])
// {
//   this.router.navigate(['/jeans']);
// }
// else{
//   console.log("invalid");
// }

this.router.navigate(['/']); 
    
   
  }

}


