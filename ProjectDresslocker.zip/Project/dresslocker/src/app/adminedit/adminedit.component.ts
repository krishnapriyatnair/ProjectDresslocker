import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import{KurthaModel}from '../kurthas/kurtha.model'
import { from } from 'rxjs';
@Component({
  selector: 'app-adminedit',
  templateUrl: './adminedit.component.html',
  styleUrls: ['./adminedit.component.css']
})
export class AdmineditComponent implements OnInit {
title:String="Edit/Delete product list";
products:KurthaModel[];

imageWidth:number=100;
imageMargin:number=2;

  constructor(private productService:ProductsService,private router:Router) { }

  ngOnInit(): void {
    this.productService.getProducts().subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })}

    deleteProduct(id)
   {
     console.log("delete call"+id);
     
     this.productService.deletePro(id)
     .subscribe(
     
      err =>{
        if (err instanceof HttpErrorResponse){
          if(err.status===401){
            this.router.navigate(['/login'])
          }
        }
      }
     )
     console.log("Product Deleted!");
     alert("Product Deleted!");
     this.router.navigate(['/edit']);
   }
 
   
 
 }











