import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(public http:HttpClient) { }

getKurthas(){
  return this.http.get("http://localhost:3000/kurthas");
}
getSarees(){
  return this.http.get("http://localhost:3000/sarees");
}

getJeans(){
  return this.http.get("http://localhost:3000/jeans");
}
getGowns(){
  return this.http.get("http://localhost:3000/gowns");
}
getProducts(){
 return this.http.get("http://localhost:3000/adminedit");
 
}
sellproduct(item){
  return this.http.post("http://localhost:3000/insert",{"product":item});
}


getProduct(id){
  return this.http.post("http://localhost:3000/product",{"id":id});
}
deletePro(item){
  
  return this.http.post("http://localhost:3000/remove" ,{"id":item});
}
updatePro(item){

  return this.http.post("http://localhost:3000/edit",{"product":item}).subscribe((status)=>{
    console.log("updated");
  });
}
payments(){

  return this.http.get("http://localhost:3000/payment");
  
}

}
