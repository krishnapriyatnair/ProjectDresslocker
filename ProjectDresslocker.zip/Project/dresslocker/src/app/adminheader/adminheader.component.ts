import { Component, OnInit } from '@angular/core';
import{UserService}from '../user.service';
@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {

  constructor(public userService:UserService) { }
  title:String="Admin page";
  ngOnInit(): void {
  }

}
