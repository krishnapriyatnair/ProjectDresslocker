import { TestBed } from '@angular/core/testing';

import { TolenInterceptorService } from './tolen-interceptor.service';

describe('TolenInterceptorService', () => {
  let service: TolenInterceptorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TolenInterceptorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
