import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KurthasComponent } from './kurthas.component';

describe('KurthasComponent', () => {
  let component: KurthasComponent;
  let fixture: ComponentFixture<KurthasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KurthasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KurthasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
