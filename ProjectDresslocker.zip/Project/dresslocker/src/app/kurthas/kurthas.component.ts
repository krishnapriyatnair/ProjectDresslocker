import { Component, OnInit } from '@angular/core';
import{KurthaModel}from './kurtha.model';
import{ProductsService} from '../products.service';
import { from } from 'rxjs';



@Component({
  selector: 'app-kurthas',
  templateUrl: './kurthas.component.html',
  styleUrls: ['./kurthas.component.css']
})
export class KurthasComponent implements OnInit {
title:String="Kurthas";
kurthas:KurthaModel[];

imageWidth: number=100;
imageMargin:number=2;

constructor(private productsService: ProductsService) { }

  ngOnInit(): void {


    this.productsService.getKurthas().subscribe((data)=>{
      console.log(data);
      this.kurthas=JSON.parse(JSON.stringify(data));
    })
  }

}
