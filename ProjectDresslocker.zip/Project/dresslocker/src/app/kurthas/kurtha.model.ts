export class KurthaModel{
    constructor(
       public  productName: string,
       public  price:number,
       public  productCode:string,
       public  productDate:string,
       public  productAvail:string,
       public  productNumber:number,
       public  description:string,
       public  imageUrl:string,
       public type:string
    ){}
}